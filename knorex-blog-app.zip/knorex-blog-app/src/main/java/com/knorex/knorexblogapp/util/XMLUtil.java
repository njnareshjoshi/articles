package com.knorex.knorexblogapp.util;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.File;
import java.util.ArrayList;
import java.util.List;


/**
 * @author Naresh Joshi
 */

public interface XMLUtil {

    static Element getDocumentElement(File file) {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        try {
            DocumentBuilder db = dbf.newDocumentBuilder();
            Document dom = db.parse(file);
            Element rootElement = dom.getDocumentElement();
            rootElement.normalize();
            return rootElement;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    static Element getChild(Element e, String tag) {
        return getChildren(e).stream()
                .filter(ele -> ele.getNodeName().equals(tag))
                .findFirst()
                .orElse(null);
    }

    static Element getElement(Node n) {
        return (Element) n;
    }


    static List<Element> getChildren(Element e) {
        List<Element> elementList = new ArrayList<>();
        NodeList nl = e.getChildNodes();
        for (int i = 0; i < nl.getLength(); i++) {
            Node currentNode = nl.item(i);
            if (currentNode.getNodeType() == Node.ELEMENT_NODE)
                elementList.add(getElement(currentNode));
        }
        return elementList;
    }

    static List<Element> getAllChildren(Element e, String tag) {
        List<Element> nl = new ArrayList<>();
        NodeList nx = e.getElementsByTagName(tag);
        for (int i = 0; i < nx.getLength(); i++) {
            Element n = getElement(nx.item(i));
            nl.add(n);
        }
        return nl;
    }

    static String getTagValue(Element ele) {
        return ele.getFirstChild().getTextContent();
    }

}
