package com.knorex.knorexblogapp.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.util.Date;

@Document
public class Article {

    @Id
    @Field("_id")
    private String guid;

    @Field
    private String link;

    @Field
    private String title;

    @Field
    private String description;

    @Field
    private Date pubdate;

    @Field
    private String category;

    @Field
    private String content;

    public Article() {
    }

    public Article(String guid, String link, String title, String description,
                   Date pubdate, String category, String content) {
        this.guid = guid;
        this.link = link;
        this.title = title;
        this.description = description;
        this.pubdate = pubdate;
        this.category = category;
        this.content = content;
    }

    public String getGuid() {
        return guid;
    }

    public void setGuid(String guid) {
        this.guid = guid;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getPubdate() {
        return pubdate;
    }

    public void setPubdate(Date pubdate) {
        this.pubdate = pubdate;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    @Override
    public String toString() {
        return "Article{" +
                "guid='" + guid + '\'' +
                ", link='" + link + '\'' +
                ", title='" + title + '\'' +
                ", description='" + description + '\'' +
                ", pubdate=" + pubdate +
                ", category='" + category + '\'' +
                ", content='" + content + '\'' +
                '}';
    }
}
