package com.knorex.knorexblogapp.repository;

import com.knorex.knorexblogapp.model.Article;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface ArticleRepository extends MongoRepository<Article, String> {
}
