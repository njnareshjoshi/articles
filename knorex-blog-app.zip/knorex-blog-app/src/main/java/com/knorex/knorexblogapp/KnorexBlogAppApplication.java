package com.knorex.knorexblogapp;

import com.knorex.knorexblogapp.service.InputReader;
import com.knorex.knorexblogapp.service.OutputWriter;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import javax.annotation.Resource;

@SpringBootApplication
public class KnorexBlogAppApplication implements CommandLineRunner {


    @Resource
    InputReader inputReader;
    @Resource
    OutputWriter outputWriter;

    private final Log log = LogFactory.getLog(getClass());

    public static void main(String[] args) {
        SpringApplication.run(KnorexBlogAppApplication.class, args);
    }

    @Override
    public void run(String... strings) throws Exception {
        inputReader.readInputRssFile();
        outputWriter.writeJsonToOutputFile();

        log.info("Program completed successfully");
    }

}
