package com.knorex.knorexblogapp.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.knorex.knorexblogapp.model.Article;
import com.knorex.knorexblogapp.repository.ArticleRepository;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.Collection;

@Service
public class OutputWriter {

    @Resource
    ArticleRepository articleRepository;

    private final Log log = LogFactory.getLog(getClass());

    public void writeJsonToOutputFile() {
        try (BufferedWriter br = new BufferedWriter(new FileWriter("output/out.json"))) {

            ObjectMapper mapper = new ObjectMapper();
            Collection<Article> articles = articleRepository.findAll();

            br.write(mapper.writeValueAsString(articles));
            br.flush();

            log.info("All articles written out.json file under out folder successfully ");
        } catch (Exception ex) {
            throw new RuntimeException("Exception while writing json to output file");
        }
    }

}
