package com.knorex.knorexblogapp.service;

import com.knorex.knorexblogapp.util.XMLUtil;
import com.knorex.knorexblogapp.model.Article;
import com.knorex.knorexblogapp.repository.ArticleRepository;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Service;
import org.w3c.dom.Element;

import javax.annotation.Resource;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

@Service
public class InputReader {

    @Resource
    ArticleRepository articleRepository;

    private final Log log = LogFactory.getLog(getClass());

    public void readInputRssFile() {

        File file = new File("input/interview/rss/521283d13a9b3e3c27b690b6");

        Collection<Article> articles = new ArrayList<>();

        Element root = XMLUtil.getDocumentElement(file);
        Element channel = XMLUtil.getChild(root, "channel");

        log.info("Reading records from file: " + file.getName());

        for (Element element : XMLUtil.getAllChildren(channel, "item")) {

            String guid = "";
            String link = "";
            String title = "";
            String description = "";
            String pubdate = "";
            String category = "";

            for (Element item : XMLUtil.getChildren(element)) {
                switch (item.getTagName()) {
                    case "guid":
                        guid = XMLUtil.getTagValue(item);
                        break;
                    case "link":
                        link = XMLUtil.getTagValue(item);
                        break;
                    case "title":
                        title = XMLUtil.getTagValue(item);
                        break;
                    case "description":
                        description = XMLUtil.getTagValue(item);
                        break;
                    case "pubdate":
                        pubdate = XMLUtil.getTagValue(item);
                        break;
                    case "category":
                        category = XMLUtil.getTagValue(item);
                        break;
                }
            }

            String content = getContentForArticle(guid);
            Article article = new Article(guid, link, title, description, new Date(pubdate), category, content);
            articles.add(article);
        }

        articleRepository.save(articles);
        log.info("All Articles inserted to MongoDB Successfully");
    }

    private String getContentForArticle(String guid) {
        try (BufferedReader br = new BufferedReader(new FileReader("input/interview/html/" + guid))) {

            String line;
            StringBuilder content = new StringBuilder("");

            while ((line = br.readLine()) != null)
                content.append(line).append("\n");

            return content.toString();
        } catch (Exception ex) {
            throw new RuntimeException("Exception while reading html files");
        }
    }
}
